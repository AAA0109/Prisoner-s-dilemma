# This file is auto-generated.
# It's used to aid autocompletion in code editors.